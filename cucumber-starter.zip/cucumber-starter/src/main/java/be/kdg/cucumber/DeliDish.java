package be.kdg.cucumber;

import java.util.LinkedList;

/**
 * Bauwen De Ron
 * 30/10/2022
 */
public class DeliDish {
    public static LinkedList<Koerier> koeriers = new LinkedList<>();
    public static LinkedList<Bestelling> bestellingen = new LinkedList<>();
    public static LinkedList<LeverOpdracht> leverOpdrachten = new LinkedList<>();
    public static LinkedList<StatusWijziging> statusWijzigingen = new LinkedList<>();
}
